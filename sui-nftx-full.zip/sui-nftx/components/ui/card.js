export function CardContent({ children }) {
  return <div className="px-2">{children}</div>;
}