
import React from "react";
import { Button } from "../components/ui/button";
import { CardContent } from "../components/ui/card";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-[#1c0039] to-[#32004d] text-white p-8">
      <h1 className="text-4xl md:text-6xl font-bold text-center mb-12 tracking-wide">
        Sui<span className="text-purple-400">NFTX</span>
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
        {[1, 2, 3].map((i) => (
          <motion.div
            key={i}
            whileHover={{ scale: 1.05 }}
            className="bg-white/10 backdrop-blur-lg p-4 rounded-2xl shadow-xl border border-white/20"
          >
            <img
              src={`/nft${i}.png`}
              alt={`NFT ${i}`}
              className="rounded-xl w-full h-60 object-cover mb-4"
            />
            <CardContent>
              <h2 className="text-xl font-semibold mb-2">Legendary NFT #{i}</h2>
              <p className="text-sm text-white/70 mb-4">
                High-tier collectible with in-game utility.
              </p>
              <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                Buy Now
              </Button>
            </CardContent>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
